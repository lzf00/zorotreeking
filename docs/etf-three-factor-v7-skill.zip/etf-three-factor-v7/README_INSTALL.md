# ETF Three-Factor National-Team Monitor Skill v7

独立 Python 包，也可作为 AI Agent Skill（放入 `.agents/skills/` 或 `~/.agents/skills/`）。

> 启发式资金监测工具，不是投资建议。

## 解压与安装

```bash
unzip etf-three-factor-v7-skill.zip
cd etf-three-factor-v7

# 推荐：装到 agents skills
mkdir -p ~/.agents/skills
cp -R . ~/.agents/skills/etf-three-factor-v7
```

工作区默认：`~/.etf-skill/workspace/`（HTML / JSON / SQLite）。

## 依赖

```bash
python3 -m pip install -U akshare
# Python 3.7+；其余为标准库
```

## 运行

```bash
cd ~/.agents/skills/etf-three-factor-v7/scripts
python3 etf_v7_threefactor.py
```

| 命令 | 说明 |
|------|------|
| `python3 etf_v7_threefactor.py` | 完整分析 |
| `python3 etf_v7_threefactor.py --date 2026-04-30` | 指定日期 |
| `python3 etf_v7_threefactor.py --send` | 分析并发邮件 |
| `python3 etf_v7_threefactor.py --record` | 仅采集份额 |
| `python3 etf_v7_threefactor.py --stats` | 本地库状态 |

## 数据源

| 数据 | 来源 |
|------|------|
| K线（量能/方向） | 腾讯财经 `web.ifzq.gtimg.cn` |
| ETF份额（申赎） | akshare → 上交所/深交所 |

份额约 19:00 后更新。综合概率 = 量能50% + 方向20% + 份额30%。

## 邮件（可选）

```bash
export ETF_EMAIL_FROM="you@qq.com"
export ETF_EMAIL_TO="to@qq.com"
export SMTP_PASS="your-smtp-auth-code"
# 或：export QQMAIL_AUTH_CODE="..."
```

可选：`ETF_SMTP_HOST`（默认 smtp.qq.com）、`ETF_SMTP_PORT`（默认 465）。
不要把授权码写进代码或发给别人。详见 `references/config.md`。

## 包内文件

- `SKILL.md` — Agent Skill 说明
- `scripts/etf_v7_threefactor.py` — 主程序
- `scripts/etf_data_store.py` — SQLite
- `scripts/test_etf_v7_threefactor.py` — 测试
- `references/etf_model.md` — 模型原理
- `references/config.md` — 配置部署

## 输出

`~/.etf-skill/workspace/`：

- `ETF三因子分析-v7.html`
- `ETF三因子分析-v7.json`
- `etf_history.db`
