import unittest

import etf_v7_threefactor as model


class ThreeFactorModelTests(unittest.TestCase):
    def test_each_etf_uses_its_own_share_history(self):
        prices = []
        index = []
        for day in range(1, 23):
            date = f"2026-07-{day:02d}"
            prices.append({"date": date, "c": 1 + day / 100, "v": 1_000_000})
            index.append({"date": date, "c": 100 + day})

        target_date = prices[-1]["date"]
        shares = {
            "510300": {target_date: {"delta_pct": 2.0, "delta_yi": 2.0}},
            "510500": {target_date: {"delta_pct": -2.0, "delta_yi": -2.0}},
        }

        positive = model.analyze_all(prices, index, shares, "510300", target_date)
        negative = model.analyze_all(prices, index, shares, "510500", target_date)

        self.assertEqual(positive[-1]["sp"], model.sprob(2.0))
        self.assertEqual(negative[-1]["sp"], model.sprob(-2.0))
        self.assertNotEqual(positive[-1]["cp"], negative[-1]["cp"])


if __name__ == "__main__":
    unittest.main()
